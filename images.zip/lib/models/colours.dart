import 'package:flutter/material.dart';

class AppColour {
  // Background
  static const Color background = Color(0xFFF5FDF6);

  // Primary Green (for buttons or highlights)
  static const Color primaryGreen = Color(0xFF6BBF59); // Soft green

  // Secondary Green (for lighter accents or input field focus)
  static const Color secondaryGreen = Color(0xFFBCEBCB); // Pale mint green

  // Border or subtle shadows
  static const Color border = Color(0xFFB2B2B2); // Light grey

  // Text Colours
  static const Color textDark = Color(0xFF040316);
  static const Color textLight = Color(0xFF666666);

  // Error colour
  static const Color error = Color(0xFFE57373); // Soft red

  // Success colour
  static const Color success = Color(0xFF81C784); // Light green
}
